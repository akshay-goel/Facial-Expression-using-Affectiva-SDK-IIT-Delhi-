﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class ProcessCameraFeed : Form, Affdex.ImageListener
    {
        System.IO.StreamWriter file = new System.IO.StreamWriter("c:\\akshay\\test.txt");
        public ProcessCameraFeed(Affdex.Detector detector)
        {
            detector.setImageListener(this);
            InitializeComponent();
            file.WriteLine("Engagement,Valence,Contempt,Surprise,Anger,Sadness,Disgust,Fear,Joy");
        }

        public void onImageResults(Dictionary<int,Affdex.Face> faces, Affdex.Frame frame)
        {
         
            
            foreach (KeyValuePair<int, Affdex.Face> pair in faces)
            {
                Affdex.Face face = pair.Value;
                if(face!=null)
                {
                    DateTime now = DateTime.Now;
                    //file.WriteLine(now.ToString("h:mm:ss tt"));
                    int temp;
                    temp = 0;
                    foreach (PropertyInfo prop in typeof(Affdex.Emotions).GetProperties())
                    {
                        
                        float value = (float)prop.GetValue(face.Emotions, null);
                        String output = String.Format("{0}: {1:0.00}", prop.Name, value);
                        String output1 = String.Format("{0:0.00},", value);
                        String output2 = String.Format("{0:0.00} \n", value);
                        temp++;
                        System.Console.WriteLine(output);
                        if (temp <= 8) file.Write(output1);
                        else file.Write(output2);
                    }
                    //file.Write("\n");
                }
            }
            
            frame.Dispose();
        }
        public void onImageCapture(Affdex.Frame frame)
        {
            frame.Dispose();
        }
        //file.Close();
    }
}
