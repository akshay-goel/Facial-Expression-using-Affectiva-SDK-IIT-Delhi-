﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test1
{
    class Program
    {
        static void Main(string[] args)
        {
            Affdex.Detector detector = new Affdex.CameraDetector(0,20,20,3,Affdex.FaceDetectorMode.LARGE_FACES);
            ProcessCameraFeed feed = new ProcessCameraFeed(detector);
            detector.setClassifierPath("C:\\Program Files\\Affectiva\\AffdexSDK\\data");
            detector.setDetectAllEmotions(true);
            detector.setDetectBrowRaise(true);
            detector.setDetectSmirk(true);
            detector.setDetectGender(true);
            detector.setDetectGlasses(true);
            detector.start();
            feed.ShowDialog();
            detector.stop();
        }
    }
}
