﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class ProcessCameraFeed : Form, Affdex.ImageListener
    {

        System.IO.StreamWriter file = new System.IO.StreamWriter("c:\\akshay\\test.txt");
        public ProcessCameraFeed(Affdex.Detector detector)
        {
            detector.setImageListener(this);
            InitializeComponent();
        }

        public void onImageResults(Dictionary<int,Affdex.Face> faces, Affdex.Frame frame)
        {
            
            foreach (KeyValuePair<int, Affdex.Face> pair in faces)
            {
                Affdex.Face face = pair.Value;
                if(face!=null)
                {
                    DateTime now = DateTime.Now;
                    file.WriteLine(now.ToString("h:mm:ss tt"));
                    foreach (PropertyInfo prop in typeof(Affdex.Emotions).GetProperties())
                    {
                        float value = (float)prop.GetValue(face.Emotions, null);
                        String output = String.Format("{0}: {1:0.00}", prop.Name, value);
                        System.Console.WriteLine(output);
                        file.WriteLine(output);
                    }
                }
            }
            
            frame.Dispose();
        }
        public void onImageCapture(Affdex.Frame frame)
        {
            frame.Dispose();
        }
        //file.Close();
    }
}
